def saludar():
    print("Hola te saludo desde saludos.saludar()")

class Saludos:
    def __init__(self):
        print("Hola te saludo desde saludo init")
if __name__ == '__main__':
        saludar()