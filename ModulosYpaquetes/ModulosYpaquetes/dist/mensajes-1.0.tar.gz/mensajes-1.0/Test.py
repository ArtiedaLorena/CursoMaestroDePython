from ModulosYpaquetes.Mensajes.Hola.Saludos import*
from ModulosYpaquetes.Mensajes.Adios.Despedidas import *
saludar()
Saludos()
despedir()


