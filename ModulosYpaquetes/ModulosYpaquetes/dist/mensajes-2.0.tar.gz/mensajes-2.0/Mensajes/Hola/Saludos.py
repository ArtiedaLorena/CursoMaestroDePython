def saludar():
    print("Hola te saludo desde saludos.saludar()")
def prueba():
    print("Esto es una prueba de la nueva version")

class Saludos:
    def __init__(self):
        print("Hola te saludo desde saludo init")
if __name__ == '__main__':
        saludar()

